self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b8afcfaa7264068d3f26a5bff7483f14",
    "url": "/index.html"
  },
  {
    "revision": "811928ad95a7ae10e65d",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "7aa8c9fc1fc746ed8d07",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "811928ad95a7ae10e65d",
    "url": "/static/js/2.4949f2e2.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4949f2e2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7aa8c9fc1fc746ed8d07",
    "url": "/static/js/main.0bbc4cc8.chunk.js"
  },
  {
    "revision": "817d2bf81990a1d39ee2",
    "url": "/static/js/runtime-main.6537f79a.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);